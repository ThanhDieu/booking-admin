export interface FieldInDiffLang {
  en?: string;
  de?: string;
}
