export interface MediaType {
  disabled: boolean;
  file: string;
  propertyId: string;
  title: string;
  type: string;
}
