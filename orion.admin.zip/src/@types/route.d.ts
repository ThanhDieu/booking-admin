interface RouteType {}

export default RouteType;
