export { default } from './ListDetailLayout';
