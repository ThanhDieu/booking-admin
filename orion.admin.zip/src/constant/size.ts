export const LAYOUT_HEADER_HEIGHT = 52;
export const LAYOUT_FOOTER_HEIGHT = 0;
export const PAGE_HEADER_HEIGHT = 48;
export const PERPAGE = 10;
export const HORIZONTAL_SCROLL = 1000;

export const MAXIMUM_DISCOUNT_DEFAULT = 70;
export const SPECIAL_NUMBER_DEFAULT = -1