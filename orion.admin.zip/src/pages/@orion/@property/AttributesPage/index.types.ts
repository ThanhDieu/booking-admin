export default interface AttributesPageProps {}
