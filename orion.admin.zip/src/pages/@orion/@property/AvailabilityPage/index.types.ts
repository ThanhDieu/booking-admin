export default interface AvailabilityPageProps {}
