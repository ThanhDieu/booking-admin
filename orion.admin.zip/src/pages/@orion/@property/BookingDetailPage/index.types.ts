import { BookingDetailAppType } from 'services/Bookings/type';

export interface BookingDetailPageProps {
  bookingDetail: BookingDetailAppType;
}
