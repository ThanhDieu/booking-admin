export default interface BundlesPageProps {}
