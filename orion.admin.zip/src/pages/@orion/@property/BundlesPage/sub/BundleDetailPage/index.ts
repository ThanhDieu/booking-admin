export { default as BundleDetail } from './BundleDetailPage';
