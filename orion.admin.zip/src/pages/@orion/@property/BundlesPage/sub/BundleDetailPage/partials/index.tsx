export { default as GeneralInfo } from './GeneralInfo';
export { default as Calculation } from './Calculation';
export { default as SubmitButton } from './SubmitButton';

