export { default } from './PropertySettingPage';
