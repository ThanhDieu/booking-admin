import { TableListRate } from './partials';

const RatePlanListPage = () => {
  return <TableListRate />;
};
export default RatePlanListPage;
