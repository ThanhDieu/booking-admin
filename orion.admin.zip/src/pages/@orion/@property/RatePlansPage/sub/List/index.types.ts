export default interface RatePlanListProps {}
