export { default as TableRate } from './TableRate';
