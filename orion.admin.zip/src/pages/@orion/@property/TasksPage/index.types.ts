export default interface TasksPageProps {}
