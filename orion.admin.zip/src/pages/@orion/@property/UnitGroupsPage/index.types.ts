export default interface UnitGroupsPageProps {}
