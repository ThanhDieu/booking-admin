export { default as UnitGroupsDetail } from './UnitGroupsDetailPage';
