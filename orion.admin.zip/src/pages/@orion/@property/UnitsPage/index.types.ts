export default interface UnitsPageProps {}
