export { default as UnitDetail } from './UnitDetailPage';
