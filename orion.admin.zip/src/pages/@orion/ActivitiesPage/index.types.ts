export default interface ActivitiesPageProps {}
