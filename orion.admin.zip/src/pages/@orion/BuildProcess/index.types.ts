export default interface BuildProcessProps {}
