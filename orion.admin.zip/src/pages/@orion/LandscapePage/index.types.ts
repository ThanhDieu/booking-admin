export default interface LandscapeProps {}
