import { OfferDetailType } from "services/Offer/type";

export interface OfferDetailProps {
    offerDetail: OfferDetailType,
    loading?: boolean
}