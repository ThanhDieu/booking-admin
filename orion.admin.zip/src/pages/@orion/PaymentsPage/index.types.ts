export default interface PaymentsPageProps {}
