export default interface PoliciesPageProps {}
