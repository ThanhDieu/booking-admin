export { default as PolicyDetail } from './PolicyDetailPage';
