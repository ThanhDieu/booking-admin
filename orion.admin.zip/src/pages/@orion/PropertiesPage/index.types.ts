export default interface PropertiesPageProps {}
