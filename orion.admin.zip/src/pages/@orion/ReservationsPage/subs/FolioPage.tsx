/* eslint-disable @typescript-eslint/no-unused-vars */
import { ReservationDetailPageProps } from '../index.types';

const FolioPage = ({ reservationDetail }: ReservationDetailPageProps) => {
  return <div>FolioPage</div>;
};

export default FolioPage;
