/* eslint-disable @typescript-eslint/no-unused-vars */
import { ReservationDetailPageProps } from '../index.types';

const InvoicesPage = ({ reservationDetail }: ReservationDetailPageProps) => {
  return <div>InvoicesPage</div>;
};

export default InvoicesPage;
