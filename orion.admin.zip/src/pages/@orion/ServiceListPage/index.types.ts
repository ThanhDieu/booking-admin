export default interface ServiceListPageProps {}
