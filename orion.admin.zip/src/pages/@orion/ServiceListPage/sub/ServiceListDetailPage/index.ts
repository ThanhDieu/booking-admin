export { default } from './ServiceListDetailPage';
