export default interface ServiceTypePageProps {}
