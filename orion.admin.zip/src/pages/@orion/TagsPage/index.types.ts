export default interface TagsPageProps {}
