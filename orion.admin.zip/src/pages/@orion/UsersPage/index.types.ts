export default interface UsersPageProps {}
