export { default as UserDetail } from './UserDetailPage';
