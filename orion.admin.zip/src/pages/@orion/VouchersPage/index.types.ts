export default interface VouchersPageProps {}
