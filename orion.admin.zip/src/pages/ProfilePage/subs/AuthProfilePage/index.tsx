export { default } from './AuthProfilePage';
