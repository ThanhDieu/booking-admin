export { default } from './SettingPage';
