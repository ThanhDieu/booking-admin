export { default } from './LangSettingPage';
