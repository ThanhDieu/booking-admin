export { default } from './NotiSettingPage';
