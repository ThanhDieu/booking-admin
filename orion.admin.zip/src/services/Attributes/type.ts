import { BaseDataAppType, BaseType } from '@types';
export interface AttributeDetailAppType extends BaseDataAppType<BaseType> {}
export interface AttributesAppType extends DataResponseType<AttributeDetailAppType> {}
