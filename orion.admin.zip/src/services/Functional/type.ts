export interface FunctionType {
  functionId?: string;
  comment: string;
  data?: string;
  disabled: boolean;
  method: string;
  methodType: string;
  name: string;
}
