import { BaseType } from '@types';
import { PropertyType } from 'services/Users/types';

export interface ServiceTypeType extends BaseType {
  property: PropertyType;
}
